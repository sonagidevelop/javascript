<h1>진혁이가 자바스크립트 공부하는 메모장</h1>
<p>싸지방에서 하는 거임</p>

<h3>Udemy 공부 할 때</h3>
<ol>
  <li>VSCode 세팅하기. Autosave, Format on Save, Font Size</li>
  <li>강사 깃헙 드가서 파일 다운받기. <a href="https://github.com/jonasschmedtmann/complete-javascript-course">링크</a> </li>
  <li>유데미에서 코딩챌린지/어사인먼트 파일 받기<a href="https://www.udemy.com/course/the-complete-javascript-course/learn/lecture/22838299#overview">링크</a></li>
  <li>압축 풀고 VSCode에 넣기</li>
  <li>script태그 <pre><script src="script.js"></script></pre></li>
</ol>
  
